//Nicki Wahlers
//CS163
//Program3
//February 2020

//This function is my header file.
//this will hold my globals, #includes, and my class definitions

#include <iostream>
#include <cstring>
#include <cstdlib>

//constants
const int SIZE = 100;
const int MAX = 5;

//classes and structs

struct leg{
		char * name; //name of leg
		float length; //length of leg
		int traffic; //traffic level
		char * notes; //notes about the leg
		int scenic; //if scenic or not
		
		leg(); //constructor
		~leg(); //destructor
		int build(); //gets user input to build each leg
		int copy_leg(leg & to_copy); //copies leg from user to class
		int display(); //displays one leg
};



struct q_node{
	leg entry; //instance of leg struct
	q_node * next; //pointer to next q node
};

class queue{
	public: 
		queue(); //constructor
		~queue(); //destructor
		void remove_all(q_node *& current); //recursive function to delete all q_nodes
		int enqueue(leg & to_add); //enqueue to add info to rear of queue
		int dequeue(); //dequeue to remove info from front of queue
		int peek(leg & to_check); //peek passes data at front of queue
		int display_all(); //displays whole queue

 
	private:
		q_node * queue_rear; //pointer to rear of queue
};

struct s_node{
	leg * entry; //pointer to array of legs
	s_node * next; //pointer to next node
};

class stack{
	public:
		stack(); //constructor 
		~stack(); //destructor
		void remove_all(s_node *& current); //recursive function to delete all s_nodes
		int display_all(); //displays whole stack
		int peek(leg & found); //finds info at top of stack
		int push(leg & to_add); //adds info to top of stack
		int pop(); //removes info fron top of stack

	private:
		s_node * stack_head; //pointer to head of nodes
		int top_index; //index at top of the stack
};





