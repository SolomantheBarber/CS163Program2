//Nicki Wahlers
//CS163
//Program2
//February 2019

//This is my main client program
#include "program2.h"

using namespace std;

int test_menu();

int main(){

	test_menu();

	return 0;
}

int test_menu(void){
	//menu control 
	char option; // control variable for outer control menu
 
	leg temp_leg; //temporary instance of leg struct
	queue trip1; //instance of queue class. trip 1
	queue trip2; //instance of queue class. trip 2
	stack return_trip; //instance of stack class. return trip

	do{
		//BIG MENU
		cout << endl;
		cout << "Welcome to trip builder" << endl;
		cout << "--------MENU --------" << endl << endl;
		cout << "a. Trip 1" << endl;
		cout << "b. Trip 2" << endl;
		cout << "c. Return Trip " << endl;
		cout << "d. Quit" << endl << endl << endl;

		cout << "Enter option: ";
		cin >> option;
		cin.ignore();




		//WORKING WITH TRIP 1
		if(option == 'a' || option == 'A')
		{
			//menu choice
			char choice; //control variable for inner menus

			
			//TRIP 1 MENU
			do{

				// MENU FOR TRIP 1
				cout << endl;
				cout << "-----TRIP 1 MENU -----" << endl;
				cout << "a. Add leg " << endl;
				cout << "b. Remove first leg" << endl;
				cout << "c. Look at first leg" << endl;
				cout << "d. Display Trip " << endl;
				cout << "e. Quit Trip 1" << endl;

				cout << "Enter choice: ";
				cin >> choice;
				cin.ignore();



				//ENQUEUE
				if(choice == 'a' || choice == 'A')
				{
					if(temp_leg.build())
						cout << "Successfully built" << endl;
					else{
						cout << "failed to build" << endl;
					}
					if(trip1.enqueue(temp_leg)){
						cout << "Successfully enqueued" << endl;
					}
					else{
						cout << "Failed to enqueue" << endl;
					}

				}


				//DEQUEUE
				else if(choice == 'b' || choice == 'B')
				{
					if(trip1.dequeue()){
						cout << "Successfully removed leg" << endl;
					}
					else{
						cout << "Failed to remove leg" << endl;
					}
				}
				//DISPLAY WHOLE LIST
				else if(choice == 'd' || choice == 'D')
				{
					if(trip1.display_all()){
						cout << "Successfully displayed trip" << endl;
					}
					else{
						cout << "Failed to display trip" << endl;
					}
				}
				//PEEK AT FRONT
				else if(choice == 'c' || choice == 'C')
				{
					if(trip1.peek(temp_leg)){
						cout << "PEEK: " << endl;
						temp_leg.display();
					}
					else{
						cout << "Failed to peek" << endl;
					}
				}


			}while(choice != 'e' && choice != 'E'); //END OF TRIP 1 MENU DO WHILE
		} //END OF WORKING WITH TRIP !
		//WORKING WITH TRIP 
		if(option == 'b' || option == 'B')
		{
			//menu choice
			char choice; //control variable for inner menus

			
			//TRIP 2 MENU
			do{

				// MENU FOR TRIP 2
				cout << endl;
				cout << "-----TRIP 2 MENU -----" << endl;
				cout << "a. Add leg " << endl;
				cout << "b. Remove first leg" << endl;
				cout << "c. Look at first leg" << endl;
				cout << "d. Display Trip " << endl;
				cout << "e. Quit Trip 2" << endl;

				cout << "Enter choice: ";
				cin >> choice;
				cin.ignore();



				//ENQUEUE
				if(choice == 'a' || choice == 'A')
				{
					if(temp_leg.build())
						cout << "Successfully built" << endl;
					else{
						cout << "failed to build" << endl;
					}
					if(trip2.enqueue(temp_leg)){
						cout << "Successfully enqueued" << endl;
					}
					else{
						cout << "Failed to enqueue" << endl;
					}

				}


				//DEQUEUE
				else if(choice == 'b' || choice == 'B')
				{
					if(trip2.dequeue()){
						cout << "Successfully removed leg" << endl;
					}
					else{
						cout << "Failed to remove leg" << endl;
					}
				}
				//DISPLAY WHOLE LIST
				else if(choice == 'd' || choice == 'D')
				{
					if(trip2.display_all()){
						cout << "Successfully displayed trip" << endl;
					}
					else{
						cout << "Failed to display trip" << endl;
					}
				}
				//PEEK AT FRONT
				else if(choice == 'c' || choice == 'C')
				{
					if(trip2.peek(temp_leg)){
						cout << "PEEK: " << endl;
						temp_leg.display();
					}
					else{
						cout << "Failed to peek" << endl;
					}
				}


			}while(choice != 'e' && choice != 'E'); //END OF TRIP 2 MENU DO WHILE
		}

		if(option == 'c' || option == 'C'){
			//TODO do i need a menu for return trip?
			int num; //control for user choice for which trip to work with
			//push
			cout << "Would you like to work with trip 1 or trip 2 (enter 1 or 2): " << endl;
			cin >> num;
			cin.ignore();
			if(num == 1){
				while(trip1.peek(temp_leg)){
					return_trip.push(temp_leg);
					trip1.dequeue();
				}
			}
			else if(num == 2){
				while(trip2.peek(temp_leg)){
					return_trip.push(temp_leg);
					trip1.dequeue();
				}
			}

			return_trip.display_all();
			
			

		}//END OF WORKING WITH RETURN TRIP

		

		}while(option != 'd' || option == 'D'); //END OF BIG MENU
		return 0;
}
