//Nicki Wahlers
//CS163
//Program2
//February 2020

//STACK CLASS 
//function implementations
#include "program2.h"

//stack constructor
//initializes private data members of stack class
stack::stack(){
	stack_head = NULL;
	top_index = 0;
}

//stack destructor
//releases dynamic memory
stack::~stack(){
	remove_all(stack_head);
}

void stack::remove_all(s_node * &current){
	if(!current)
		return;
	remove_all(current -> next);
	//if(current -> entry){
		//for(int i = 0; i < top_index; ++i){
			//delete current -> entry[i];
			//current ->entry[i] = NULL;
		//}
		delete [] current ->entry;
		current -> entry = NULL;
	//}
	delete current;
	current = NULL;	
}


//push function
//pushes information to the front of the stack
//information to add passed as argument
//returns int for success failure reporting
int stack::push( leg & to_add){
	
	if(!stack_head){
		stack_head = new s_node;
		stack_head -> entry = new leg[MAX];
		stack_head -> next = NULL;
		if(stack_head -> entry[top_index].copy_leg(to_add)){
			++top_index;
			return 1;
		}
	}

	if(top_index < MAX){
		if(stack_head -> entry[top_index].copy_leg(to_add)){
			++top_index;
			return 1;
		}
	}

	if(top_index == MAX){
		s_node * temp = stack_head;
		stack_head = new s_node;
		stack_head -> entry = new leg[MAX];
		stack_head -> next = temp;
		
		top_index = 0;
		if(stack_head -> entry[top_index].copy_leg(to_add)){
			++top_index;
			return 1;
		}
	}
	return 0;
}


//pop function
//removes data from the top of the stack
//no arguments
//returns int for success failure reporting
int stack::pop(){
	if(!stack_head)
		return 0;
	
	if(top_index > 1){
		--top_index;
		return 1;
	}

	if(top_index == 1){
		top_index = MAX;
		s_node * temp = stack_head;
		stack_head = stack_head -> next;
		delete temp;
	}
	return 1;
}


//peek function
//passes information about what is at the top of the stack
//info at top of stack as argument by reference
//returns int for success failure reporting
int stack::peek(leg & found){
	if(!stack_head)
		return 0;

	else{
		stack_head -> entry[top_index].copy_leg(found);
		return 1;
	}
}


//display all function
//displays all information located in stack
//no arguments
//returns int for success failure reporting
int stack::display_all(){
	if(!stack_head)
		return 0;

	s_node * temp = stack_head;
	int temp_index = top_index;
	while(temp){
		while(temp_index > 0){
			temp -> entry[temp_index - 1].display();
			--temp_index;
		}
		temp = temp -> next;
		temp_index = MAX;
	}
	return 1;
}
