//Nicki Wahlers
//CS163
//Program2
//February 2020

//LEG CLASS 
//function implementations
#include "program2.h"
using namespace std;

/*
Constructor
Initializes data memebers to NULL value
*/

leg::leg(){
	name = NULL;
	length = 0;
	traffic = 0;
	notes = NULL;
	scenic = 0;
}


/*
Destructor
Deallocates dynamic memory to prevent memory leaks
*/
leg::~leg(){
	if(name)
		delete [] name;
	if(notes)
		delete [] notes;
}


/*
copy_leg function
copies data from a temporary instance of the leg class into
the data member
takes a leg as argument by reference
returns int to report success or failure.
*/
int leg::copy_leg(leg & a_leg){
	//TODO: take all the elements from a_leg,
	//store them in the leg class

	if(name)
		delete [] name;
	length = 0;
	traffic = 0;
	if(notes)
		delete [] notes;
	scenic = 0;

	name = new char[strlen(a_leg.name) + 1];
	strcpy(name, a_leg.name);

	length = a_leg.length;

	traffic = a_leg.traffic;

	notes = new char[strlen(a_leg.name) + 1];
	strcpy(notes, a_leg.notes);

	scenic = a_leg.scenic;
	
	return 1;
}

/*
build function
gets user input and fills temporary leg with data
takes no arguments
returns integer to report success or failure
*/
int leg::build(){
	char temp_array[SIZE];
	float temp_length = 0;
	int temp_traffic = 0;



		cout << "Enter the name of a leg:" << endl;
		cin.get(temp_array, 100, '\n');
		cin.ignore(100, '\n');
		name = new char[strlen(temp_array) + 1];
		strcpy(name, temp_array);

		cout << "Enter length of leg (in miles): " << endl;
		cin >> length;
		cin.ignore();
		length = length;
		

		cout << "Enter the traffic level (1-light 5-heavy): " << endl;
		cin >> traffic;
		cin.ignore();
		traffic = traffic;	

		cout << "Enter any notes about this leg: " << endl;
		cin.get(temp_array, 100, '\n');
		cin.ignore(100, '\n');
		notes = new char[strlen(temp_array) + 1];
		strcpy(notes, temp_array);

		cout << "Enter if scenic (1 for yes, 0 for no): " << endl;
		cin >> scenic;

	return 1;
}


/*
display function
displays data of one leg
takes no arguments
returns and int for success or failure
*/
int leg::display(){
	if(!name || !length || !traffic || !notes || !scenic){
		return 0;
	}
	cout << endl;
	cout << "Name: " << name << endl;
	cout << "Length: " << length << endl;
	cout << "Traffic Level: " << traffic << endl;
	cout << "Notes: " << notes << endl;
	cout << "Scenic: " << scenic << endl;
	cout << endl;
	return 1;
}








