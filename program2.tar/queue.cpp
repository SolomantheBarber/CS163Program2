//Nicki Wahlers
//CS163
//Program2
//February 2020

//QUEUE CLASS 
//function implementations
#include "program2.h" 

//Queue constructor
//initializes private data members
queue::queue(){
	queue_rear = NULL;
}


//Queue destructor
//releases dynamic memory to prevent memory leaks
queue::~queue(){
	if(queue_rear)
	{
		q_node * temp = queue_rear -> next;
		queue_rear -> next = NULL;
		queue_rear = temp;

		remove_all(queue_rear);
	}

}

void queue::remove_all(q_node * &current){
	if(!current)
		return;
	remove_all(current -> next);
	delete current;
	current = NULL;
	
}

//enqueue function
//adds a leg of the journy to the circular linked list
//takes leg to add as argument
//returns integer for success failure reporting
int queue::enqueue(leg & to_add){
	
	if(!queue_rear){
		queue_rear = new q_node;
		queue_rear -> next = queue_rear;
		queue_rear -> entry.copy_leg(to_add);
		return 1;
	}

	else{
		q_node * temp = queue_rear -> next;
		queue_rear -> next = new q_node;
		queue_rear = queue_rear -> next;
		queue_rear -> next = temp;
		queue_rear -> entry.copy_leg(to_add);
		return 1;	
	}
	return 0;
}


//dequeue function
//removes a leg from the front of the circular linked list
//no arguments
//returns integer for success failure reporting
int queue::dequeue(){
	if(!queue_rear)
		return 0;

	else if(queue_rear -> next == queue_rear){
		delete queue_rear;
		queue_rear -> next = NULL;
		queue_rear = NULL;
		return 1;
	}
	else{
		q_node * temp = queue_rear -> next;
		queue_rear -> next = temp -> next;
		delete temp;
		temp = NULL;
		return 1;
	}
	return 0;
}


//display all function
//displays every node of circular linked list
//no arguments
//returns int for success failure reporting
int queue::display_all(){
	if(!queue_rear)
		return 0;
	
	q_node * temp = queue_rear -> next;
	temp -> entry.display();
	temp = temp -> next;

	while(temp != queue_rear -> next){
		temp -> entry.display();
		temp = temp -> next;
	}
	return 1;
}


//peek function
//looks at node at front of list and passes data back in argument by reference
//leg instance by reference
//returns int for success failure reporting
int queue::peek(leg & to_check){
	if(!queue_rear){
		return 0;
	}
	else{
		to_check = queue_rear -> next -> entry;
		return 1;
	}
}





